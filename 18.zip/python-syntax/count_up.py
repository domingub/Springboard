def count_up(start, stop):
  While start <= stop:
    print(start)
    start = start + 1;

count_up(5, 7)        
