def sum_nums(nums):
  x = 0:
    for num in nums:
      x = x + num;
  return x;

print("sum_nums returned", sum_nums([1, 2, 3, 4]))
