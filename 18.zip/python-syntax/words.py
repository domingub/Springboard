def print_upper_words(list):
  for word in list:
    print(word.upper);

def print_upper_words2(list):
  for word in list:
    word.upper();
    if word.startswith("E"):
      print(word);

def print_upper_words3(list, starting_letter):
  for word in list:
    word.upper();
    for letter in starting_letter:
      if word.startswith(letter):
        print (word)
