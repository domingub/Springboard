def in_range(nums, lowest, highest):
  for num in nums:
    if num >= Lowest and num <= highest:
      print(num, " fits");  


in_range([10, 20, 30, 40, 50], 15, 30)            
